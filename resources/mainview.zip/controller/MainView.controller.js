sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("mainview.controller.MainView",{onInit(){}})});
//# sourceMappingURL=MainView.controller.js.map